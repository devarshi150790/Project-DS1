package edu.buffalo.cse.cse486586.simplemessenger;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.content.Context;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnKeyListener;
import android.widget.EditText;
import android.widget.TextView;


public class MainActivity extends Activity {
	public final static String TAG="tag";
	public String mssg;
	Socket sock;
	ServerSocket server;
	Socket serverSock;
	BufferedReader inputs;
	String inputLine;
	String portStr;
	String ip="10.0.2.2";
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		final EditText editText=(EditText)findViewById(R.id.editText1);
		editText.setOnKeyListener(new OnKeyListener() {

			@Override
			public boolean onKey(View v, int keyCode, KeyEvent event) {
				//Tracking Key Events 
			if(keyCode != KeyEvent.KEYCODE_ENTER)	
			{
				mssg=editText.getText().toString();			
			}
			else if (keyCode == KeyEvent.KEYCODE_ENTER)
				{
				
					Client c=new Client();
					c.executeOnExecutor(AsyncTask.SERIAL_EXECUTOR);					
					editText.setText("");
				}
				Log.v(TAG, mssg);
				return false;
			}
		});
				// Obtain substring of telephone number
		TelephonyManager tel =(TelephonyManager) this.getSystemService(Context.TELEPHONY_SERVICE);
		portStr= tel.getLine1Number().substring(tel.getLine1Number().length() - 4);
				
		Server s= new Server();
		s.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
		Log.v(TAG, "Server instantiated successfully");
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_main, menu);
		return true;
	}



	public class Client extends AsyncTask<Void, Void, Void>{

		@Override
		protected Void doInBackground(Void... para)
		{
			try
			{
				Log.v(TAG, "Inside doIn of Client");
				if(portStr.equals("5554")) 
				{
					sock = new Socket(InetAddress.getByName(ip),11112);
					Log.v(TAG, "connected to 5556");
				}
				else	if(portStr.equals("5556"))
				{

					sock = new Socket(InetAddress.getByName(ip),11108);
					Log.v(TAG, "connected to 5554");
				}
				DataOutputStream output = null; 

				output = new DataOutputStream(sock.getOutputStream());

				String toServer=mssg;
				
				Log.v("To Server", toServer);
				output.writeBytes(toServer);
				Log.v("Written To Server", toServer);
				output.flush(); 

			}
			catch(Exception e)
			{

			} 
				try {
					if (sock != null)
						sock.close();
				} 
				catch (final IOException ex) {
				}
			 
			return null;
		}

		protected void onPostExecute(String result) {
		}

		protected void onPreExecute() {
			}

		protected void onProgressUpdate(Void... values) {
			
		}
	}


	public class Server extends AsyncTask<Void, String, Void>{

		@Override
		protected void onProgressUpdate(String... values) {
			// TODO Auto-generated method stub
			//super.onProgressUpdate(values);
			TextView textView = (TextView) findViewById(R.id.textView1);
			textView.setText("Message: "+values[0]);
		}
		@Override
		protected Void doInBackground(Void... values)
		{
			Log.v(TAG, "Inside doIn of Server");
			server = null;
			serverSock = null;
			inputs = null;
			
			try
			{
				server = new ServerSocket(10000);
				Log.v(TAG, "Server Socket Created");
				while(true)
				{
				serverSock = server.accept();
				Log.v(TAG, "Call Accepted");
				inputs = new BufferedReader(new InputStreamReader(serverSock.getInputStream()));
				Log.v(TAG, "Got Input Stream");
				if(inputs!=null)
					inputLine = inputs.readLine();
				Log.v("Print Input Stream", inputLine);

				publishProgress(inputLine);
				}
			}
			catch(IOException e)
			{

			} 
			
			try {
					if (serverSock != null) 
						serverSock.close();
				
				} catch (final IOException ex) {
				}
			
				try {
				if (server != null) 
					server.close();
				
			} catch (final IOException ex) {
			}
			return null;
		}

		protected void onPostExecute(String result) {
		}

		protected void onPreExecute() {
		}

	}

}
